package org.dimdev.limlib.api.skybox;

import com.mojang.serialization.MapCodec;
import net.fabricmc.fabric.api.event.registry.DynamicRegistries;
import org.dimdev.limlib.api.LimLibRegistries;
import org.dimdev.limlib.api.Utils;
import org.dimdev.limlib.impl.Limlib;
import net.minecraft.core.MappedRegistry;
import net.minecraft.core.Registry;

public record SkyboxType<T extends Skybox>(MapCodec<T> codec) {

}
