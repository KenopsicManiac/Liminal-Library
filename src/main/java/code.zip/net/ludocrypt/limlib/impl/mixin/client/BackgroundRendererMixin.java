package org.dimdev.limlib.impl.mixin.client;

import java.util.Optional;
import java.util.function.Function;

import org.dimdev.limlib.api.LimLibRegistries;
import net.minecraft.client.multiplayer.ClientLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import org.dimdev.limlib.api.effects.LookupGrabber;
import org.dimdev.limlib.api.effects.sky.DimensionEffects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.resources.ResourceKey;

@Mixin(FogRenderer.class)
public abstract class BackgroundRendererMixin {
	@ModifyVariable(method = "setupColor", at = @At(value = "STORE", ordinal = 3), ordinal = 2)
	private static float limlib$modifySkyColor(float in) {

		return LookupGrabber.snatchFromLevel(Minecraft.getInstance().level, LimLibRegistries.DIMENSION_EFFECTS)
			.map(DimensionEffects::skyShading)
			.orElse(in);
	}

}
