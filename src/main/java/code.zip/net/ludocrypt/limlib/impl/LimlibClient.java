package org.dimdev.limlib.impl;

import net.fabricmc.api.ClientModInitializer;

import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import org.dimdev.limlib.impl.shader.PostProcesserManager;
import net.minecraft.server.packs.PackType;

public class LimlibClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		ResourceManagerHelper.get(PackType.CLIENT_RESOURCES).registerReloadListener(PostProcesserManager.INSTANCE);
	}

}
